package com.hcs.business.academic;

import java.util.Collections;
import java.util.List;

public class AppTest{

	public static void main(String[] args) {
		Pair<String,Integer> order = new OrderPair<>("Sahil", 3);
		Pair<String,Integer> order2 = new OrderPair<>("Sahil", 4);
		
		System.out.println(Util.<String,Integer>compare(order, order2));
		List<String> list = Util.<String>emptyList();
		
		
	}
}

class Util{

	public static <T> List<T> emptyList(){
		return Collections.<T>emptyList();
	}
	
	public static <K,V> boolean compare(Pair<K,V> p1, Pair<K,V> p2) {
		return p1.getKey().equals(p2.getKey()) && p1.getValue().equals(p2.getValue());
	}
	
}

interface Pair<K,V>{
	public K getKey();
	public V getValue();
}

class OrderPair<K,V> implements Pair<K,V>{

	K k;
	V v;
	
	public OrderPair(K k,V v) {
		this.k=k;
		this.v=v;
	}
	
	@Override
	public K getKey() {
		return this.k;
	}

	@Override
	public V getValue() {
		return this.v;
	}
	
}

class Test<T>{
	T t;
	
	public Test(T t) {
		this.t = t;
	}
	
	public T getObject() {
		return this.t;
	}
}