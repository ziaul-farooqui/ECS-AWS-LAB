package com.hcs.core.entity.listener;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class EntityUpdateListener {

	private static Map<String,String> prefixes = new HashMap<>();
	
}
