package com.hcs.entity;

import java.io.Serializable;
import java.util.Date;

import org.hcs.entity.IBaseEntity;

import com.hcs.core.entity.listener.EntityUpdateListener;

import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
@EntityListeners(EntityUpdateListener.class)
public abstract class BaseEntity implements IBaseEntity, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -965756452180735111L;

	public String getEntityName() {
		return "ENTITY";
	}

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "default_generator")
	protected Long pk;

	public Long getPk() {
		return pk;
	}

	public void setPk(Long pk) {
		this.pk = pk;
	}

	@Override
	public boolean equals(Object entity) {
		if (!(entity instanceof BaseEntity)) {
			return false;
		}
		BaseEntity ent = (BaseEntity) entity;
		if (ent.getPk() == null || this.getPk() == null)
			return false;
		else if (ent.getPk().equals(this.getPk())) {
			return true;
		}
		return super.equals(entity);
	}

	

}
