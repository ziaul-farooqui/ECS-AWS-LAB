package com.hcs.entity;

import java.io.Serializable;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class BaseLink implements Serializable {

	private static final long serialVersionUID = 7368861218540351863L;

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "default_link_generator")
	protected Long pk;

	private int ordinal;

	public Long getPk() {
		return pk;
	}

	public void setPk(Long pk) {
		this.pk = pk;
	}

	public int getOrdinal() {
		return ordinal;
	}

	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}
	
}
