package com.hcs.entity.academic;

import com.hcs.entity.BaseEntity;
import com.hcs.entity.common.Site;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name = "academic_session")
@TableGenerator(name = "default_generator", table = "MAXID_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", pkColumnValue = "ACADEMIC_SESSION_PK", allocationSize = 1)
public class AcademicSession extends BaseEntity {
	
	public static final String ENTITY_NAME = "ACADEMIC_SESSION";
	public String getEntityName(){
		return ENTITY_NAME;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="site_pk")
	private Site site;
	
	@Column(name = "code", unique = true, nullable = true, length = 60)
	private String code;
	@Column(name = "title", nullable = true, length = 100)
	private String title;
	
	
	@Column(name = "session_start_date")
	private long sessionStartDate;
	@Column(name = "session_end_date")
	private long sessionEndDate;
	
	private boolean active;
	private boolean deleted;
	private boolean current;
	private int ordinal;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public long getSessionStartDate() {
		return sessionStartDate;
	}
	public void setSessionStartDate(long sessionStartDate) {
		this.sessionStartDate = sessionStartDate;
	}
	public long getSessionEndDate() {
		return sessionEndDate;
	}
	public void setSessionEndDate(long sessionEndDate) {
		this.sessionEndDate = sessionEndDate;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public boolean isCurrent() {
		return current;
	}
	public void setCurrent(boolean current) {
		this.current = current;
	}
	public int getOrdinal() {
		return ordinal;
	}
	public void setOrdinal(int ordinal) {
		this.ordinal = ordinal;
	}
	public Site getSite() {
		return site;
	}
	public void setSite(Site site) {
		this.site = site;
	}
	

}
