package com.hcs.entity.academic;

import com.hcs.entity.BaseEntity;
import com.hcs.entity.common.Site;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name = "grade")
@TableGenerator(name = "default_generator", table = "MAXID_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", pkColumnValue = "GRADE_PK", allocationSize = 1)
public class Grade extends BaseEntity {
	
	public static final String ENTITY_NAME = "GRADE";
	public String getEntityName(){
		return ENTITY_NAME;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="site_pk")
	private Site site;
	
	
	@Column(name = "code", unique = true, nullable = true, length = 60)
	private String code;
	@Column(name = "title", nullable = true, length = 100)
	private String title;
	
	private boolean active;
	private int level;
	public Site getSite() {
		return site;
	}
	public void setSite(Site site) {
		this.site = site;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	
	
}
