package com.hcs.entity.academic;

import com.hcs.entity.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name = "session_class")
@TableGenerator(name = "default_generator", table = "MAXID_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", pkColumnValue = "SESSION_CLASS_PK", allocationSize = 1)
public class SessionClass extends BaseEntity {

	public static final String ENTITY_NAME = "ACADEMIC_SESSION";
	public String getEntityName(){
		return ENTITY_NAME;
	}
	
	@Column(name = "code", unique = true, nullable = true, length = 60)
	private String code;	

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="grade_pk")
	private Grade grade;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="session_pk")
	private AcademicSession session;
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public AcademicSession getSession() {
		return session;
	}

	public void setSession(AcademicSession session) {
		this.session = session;
	}
	
}
