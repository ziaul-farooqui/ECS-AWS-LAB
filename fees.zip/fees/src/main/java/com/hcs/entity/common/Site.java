package com.hcs.entity.common;

import java.util.Date;

import com.hcs.entity.BaseEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name = "site")
@TableGenerator(name = "default_generator", table = "MAXID_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", pkColumnValue = "SITE_PK", allocationSize = 1)
public class Site extends BaseEntity {
	
	
	public static final String ENTITY_NAME = "SITE";
	public String getEntityName(){
		return ENTITY_NAME;
	}
	
	@Column(name = "code", unique = true, nullable = true, length = 60)
	private String code;
	@Column(name = "title", nullable = true, length = 100)
	private String title;
	@Column(name = "active")
	private boolean active;
	@Column(name = "deleted")
	private boolean deleted;
	@Column(name = "created_date")
	private long createdDate;
	@Column(name = "modified_date")
	private long modifiedDate;

	
	public Site() {
		this.active = true;
		this.deleted = false;
		this.createdDate = System.currentTimeMillis();
		this.modifiedDate = System.currentTimeMillis();
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	public boolean isActive() {
		return active;
	}

	
	public void setActive(boolean active) {
		this.active = active;
	}

	
	public boolean isDeleted() {
		return deleted;
	}

	
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	
	public Date getCreatedDate() {
		return new Date(createdDate);
	}

	
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate.getTime();
	}

	
	public Date getModifiedDate() {
		return new Date(modifiedDate);
	}

	
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate.getTime();
	}

	
	public int hashCode() {
		return (getPk() != null ? getPk().hashCode() : 0);
	}
	
}

