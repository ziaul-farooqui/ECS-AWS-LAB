package com.hcs.entity.fee;

import java.util.ArrayList;
import java.util.List;

import com.hcs.entity.BaseEntity;
import com.hcs.entity.common.Site;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name = "fee")
@TableGenerator(name = "default_generator", table = "MAXID_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", pkColumnValue = "FEE_PK", allocationSize = 1)
public class Fee extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="site_pk")
	private Site site;
	
	private String title;
	private String code;
	
	@OneToMany(mappedBy = "fee")
	@OrderColumn(name="ordinal")
	private List<FeeGradeLink> grades = new ArrayList<FeeGradeLink>();

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public List<FeeGradeLink> getGrades() {
		return grades;
	}

	public void setGrades(List<FeeGradeLink> grades) {
		this.grades = grades;
	}
	
}
