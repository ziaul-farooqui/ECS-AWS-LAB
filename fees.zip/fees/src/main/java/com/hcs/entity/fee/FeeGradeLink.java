package com.hcs.entity.fee;

import com.hcs.entity.BaseLink;
import com.hcs.entity.academic.Grade;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name="link_fee_grade")
@TableGenerator(pkColumnValue = "FEE_GRADE_PK", name = "default_link_generator", table = "MAXID_LINK_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", allocationSize = 50)
public class FeeGradeLink extends BaseLink {

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "fee_pk",referencedColumnName="pk")
	private Fee fee;
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "grade_pk",referencedColumnName="pk")
	private Grade grade;
	
	public FeeGradeLink(Fee fee, Grade grade) {
		super();
		this.fee = fee;
		this.grade = grade;
	}

	public FeeGradeLink() {
		// TODO Auto-generated constructor stub
	}

	public Fee getFee() {
		return fee;
	}

	public void setFee(Fee fee) {
		this.fee = fee;
	}

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}
	
}
