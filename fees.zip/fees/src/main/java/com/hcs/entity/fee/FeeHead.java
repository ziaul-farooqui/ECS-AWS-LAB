package com.hcs.entity.fee;

import java.util.ArrayList;
import java.util.List;

import com.hcs.entity.BaseEntity;
import com.hcs.entity.common.Site;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name = "fee_head")
@TableGenerator(name = "default_generator", table = "MAXID_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", pkColumnValue = "FEE_HEAD_PK", allocationSize = 1)
public class FeeHead extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="fee_pk")
	private Fee fee;
	
	private String title;
	private String code;
	
	@OneToMany(mappedBy = "fee")
	@OrderColumn(name="ordinal")
	private List<FeeGroupLink> feeGroups = new ArrayList<FeeGroupLink>();

	public Fee getFee() {
		return fee;
	}

	public void setFee(Fee fee) {
		this.fee = fee;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public List<FeeGroupLink> getFeeGroups() {
		return feeGroups;
	}

	public void setFeeGroups(List<FeeGroupLink> feeGroups) {
		this.feeGroups = feeGroups;
	}

	
}
