package com.hcs.entity.fee;

import com.hcs.entity.BaseEntity;
import com.hcs.entity.common.Site;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name = "fee_head_group")
@TableGenerator(name = "default_generator", table = "MAXID_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", pkColumnValue = "FEE_HEAD_GROUP_PK", allocationSize = 1)
public class FeeHeadGroup extends BaseEntity {

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="site_pk")
	private Site site;
	
	private String title;
	private boolean fixed=true;
	private boolean adhoc;
	private boolean fineHead;
	
	public Site getSite() {
		return site;
	}
	public void setSite(Site site) {
		this.site = site;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public boolean isFixed() {
		return fixed;
	}
	public void setFixed(boolean fixed) {
		this.fixed = fixed;
	}
	public boolean isAdhoc() {
		return adhoc;
	}
	public void setAdhoc(boolean adhoc) {
		this.adhoc = adhoc;
	}
	public boolean isFineHead() {
		return fineHead;
	}
	public void setFineHead(boolean fineHead) {
		this.fineHead = fineHead;
	}
	
}
