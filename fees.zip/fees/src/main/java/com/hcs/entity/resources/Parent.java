package com.hcs.entity.resources;

import com.hcs.entity.BaseEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;

@Entity
@Table(name = "parent")
@TableGenerator(name = "default_generator", table = "MAXID_GEN", pkColumnName = "GEN_KEY", valueColumnName = "GEN_VALUE", pkColumnValue = "PARENT_PK", allocationSize = 1)
public class Parent extends BaseEntity {
	
	String userName;
	String password;
	String token;
	
	Address currentAddress;
	boolean permanent;
	Address permanentAddress;
	
	boolean singleParent;
	Guardian father;
	Guardian mother;
	Guardian guardian;
	
	
}
