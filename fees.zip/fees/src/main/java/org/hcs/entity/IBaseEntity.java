package org.hcs.entity;

public interface IBaseEntity {

	public Long getPk();

	public void setPk(Long pk);
}
