package com.hcs.academic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeesApplicationTests {

	@Test
	void contextLoads() {
	}

}
